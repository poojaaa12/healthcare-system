CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  email TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile select" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "own profile delete" ON public.profiles FOR DELETE TO authenticated USING (auth.uid() = id);

CREATE TABLE public.reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT,
  file_type TEXT,
  file_size BIGINT,
  upload_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  processing_status TEXT NOT NULL DEFAULT 'pending',
  processing_error TEXT,
  ocr_text TEXT,
  ocr_mode TEXT,
  analyzed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX reports_user_id_idx ON public.reports(user_id);
CREATE INDEX reports_upload_date_idx ON public.reports(upload_date DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reports TO authenticated;
GRANT ALL ON public.reports TO service_role;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own reports select" ON public.reports FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own reports insert" ON public.reports FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own reports update" ON public.reports FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own reports delete" ON public.reports FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.extracted_parameters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id UUID NOT NULL REFERENCES public.reports(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  parameter_name TEXT NOT NULL,
  value NUMERIC,
  raw_value TEXT,
  unit TEXT,
  reference_range TEXT,
  status TEXT NOT NULL DEFAULT 'unknown',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX extracted_parameters_report_idx ON public.extracted_parameters(report_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.extracted_parameters TO authenticated;
GRANT ALL ON public.extracted_parameters TO service_role;
ALTER TABLE public.extracted_parameters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own params select" ON public.extracted_parameters FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own params insert" ON public.extracted_parameters FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own params update" ON public.extracted_parameters FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own params delete" ON public.extracted_parameters FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.risk_analysis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id UUID NOT NULL REFERENCES public.reports(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  risk_level TEXT NOT NULL,
  risk_score NUMERIC,
  model_type TEXT NOT NULL DEFAULT 'prototype-rule-ensemble',
  analysis_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX risk_analysis_report_idx ON public.risk_analysis(report_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.risk_analysis TO authenticated;
GRANT ALL ON public.risk_analysis TO service_role;
ALTER TABLE public.risk_analysis ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own risk select" ON public.risk_analysis FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own risk insert" ON public.risk_analysis FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own risk update" ON public.risk_analysis FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own risk delete" ON public.risk_analysis FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.ai_explanations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id UUID NOT NULL REFERENCES public.reports(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  explanation TEXT NOT NULL,
  model_type TEXT NOT NULL DEFAULT 'demo',
  is_demo BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ai_explanations_report_idx ON public.ai_explanations(report_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ai_explanations TO authenticated;
GRANT ALL ON public.ai_explanations TO service_role;
ALTER TABLE public.ai_explanations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own expl select" ON public.ai_explanations FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own expl insert" ON public.ai_explanations FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own expl update" ON public.ai_explanations FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own expl delete" ON public.ai_explanations FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.organ_mappings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id UUID NOT NULL REFERENCES public.reports(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  organ_id TEXT NOT NULL,
  organ_name TEXT NOT NULL,
  related_parameters TEXT[] NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'normal',
  explanation TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX organ_mappings_report_idx ON public.organ_mappings(report_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organ_mappings TO authenticated;
GRANT ALL ON public.organ_mappings TO service_role;
ALTER TABLE public.organ_mappings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own organ select" ON public.organ_mappings FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own organ insert" ON public.organ_mappings FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own organ update" ON public.organ_mappings FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own organ delete" ON public.organ_mappings FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER reports_updated_at BEFORE UPDATE ON public.reports FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), NEW.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE POLICY "own report files select" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'medical-reports' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "own report files insert" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'medical-reports' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "own report files delete" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'medical-reports' AND auth.uid()::text = (storage.foldername(name))[1]);