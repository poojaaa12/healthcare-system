import { ORGANS } from "@/data/organs";
import { findDefinition } from "@/data/medicalParameters";
import type { MedicalParameter, OrganMappingResult, OrganStatus } from "@/types";

/**
 * Organ mapping + avatar service.
 *
 * Maps extracted parameters onto organs. Highlighting never states that an
 * organ is diseased — it only reports that the report contains parameters
 * commonly associated with that organ.
 */
export function mapParametersToOrgans(parameters: MedicalParameter[]): OrganMappingResult[] {
  return ORGANS.map((organ) => {
    const related = parameters.filter((p) => {
      const def = findDefinition(p.parameterName);
      return (
        organ.relatedParameters.includes(p.parameterName) ||
        (def?.organs ?? []).includes(organ.id)
      );
    });

    const attention = related.filter((p) => p.status === "high" || p.status === "low");

    let status: OrganStatus = "unmapped";
    if (related.length > 0) status = attention.length > 0 ? "attention" : "normal";

    let explanation: string;
    if (status === "unmapped") {
      explanation = `No parameters in this report are mapped to the ${organ.name.toLowerCase()}.`;
    } else if (status === "attention") {
      explanation = `This organ is highlighted because the report contains parameters commonly associated with this organ (${attention
        .map((p) => p.parameterName)
        .join(", ")}) that fall outside the reference range shown on the report. This is not a statement about the health of the organ.`;
    } else {
      explanation = `The report contains parameters commonly associated with this organ (${related
        .map((p) => p.parameterName)
        .join(", ")}), and all of them fall inside the reference range shown on the report.`;
    }

    return {
      organId: organ.id,
      organName: organ.name,
      relatedParameters: related.map((p) => p.parameterName),
      status,
      explanation,
    };
  });
}

/** Where the replaceable GLB/GLTF model is expected, if the user adds one. */
export const AVATAR_MODEL_URL = "/models/mediavatar.glb";

export async function avatarModelExists(): Promise<boolean> {
  if (typeof window === "undefined") return false;
  try {
    const res = await fetch(AVATAR_MODEL_URL, { method: "HEAD" });
    return res.ok && (res.headers.get("content-type") ?? "").includes("model") !== false && res.ok;
  } catch {
    return false;
  }
}
