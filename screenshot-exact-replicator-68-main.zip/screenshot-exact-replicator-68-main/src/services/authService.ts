import { supabase } from "@/integrations/supabase/client";

export interface AuthOutcome {
  ok: boolean;
  message?: string;
}

/** Password policy used by both registration and password changes. */
export function validatePassword(password: string): string | null {
  if (password.length < 8) return "Password must be at least 8 characters long.";
  if (!/[A-Za-z]/.test(password)) return "Password must contain at least one letter.";
  if (!/[0-9]/.test(password)) return "Password must contain at least one number.";
  return null;
}

function friendly(message: string): string {
  const m = message.toLowerCase();
  if (m.includes("invalid login")) return "That email and password combination is not correct.";
  if (m.includes("already registered") || m.includes("already been registered"))
    return "An account with this email already exists. Try signing in instead.";
  if (m.includes("email not confirmed")) return "Please confirm your email address first.";
  if (m.includes("rate limit")) return "Too many attempts. Please wait a moment and try again.";
  return message;
}

export async function register(
  fullName: string,
  email: string,
  password: string,
): Promise<AuthOutcome> {
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${window.location.origin}/dashboard`,
      data: { full_name: fullName },
    },
  });
  if (error) return { ok: false, message: friendly(error.message) };
  return { ok: true };
}

export async function login(email: string, password: string): Promise<AuthOutcome> {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { ok: false, message: friendly(error.message) };
  return { ok: true };
}

export async function logout(): Promise<void> {
  await supabase.auth.signOut();
}

export async function sendPasswordReset(email: string): Promise<AuthOutcome> {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/login`,
  });
  if (error) return { ok: false, message: friendly(error.message) };
  return { ok: true };
}
