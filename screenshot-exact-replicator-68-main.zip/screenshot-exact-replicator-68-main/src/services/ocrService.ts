import type { OcrResult } from "@/types";

/**
 * OCR service.
 *
 * Real OCR runs in the browser with Tesseract.js. PDFs are first rendered to a
 * canvas with pdf.js, then passed through the same recogniser.
 *
 * If real OCR cannot run (unsupported environment, worker failure, empty
 * result) the service falls back to DEMO OCR MODE, which returns clearly
 * labelled sample text. Demo text is never presented as text extracted from a
 * real medical report.
 */

const DEMO_OCR_TEXT = `DEMO / PROTOTYPE DATA - NOT EXTRACTED FROM A REAL REPORT
=========================================================
SAMPLE LABORATORY PANEL (fictional, for demonstration only)

Hemoglobin        13.4 g/dL      (13.0 - 17.0)
WBC               9.2 10^3/uL    (4.0 - 11.0)
RBC               4.8 10^6/uL    (4.2 - 5.9)
Platelets         210 10^3/uL    (150 - 450)
Glucose           118 mg/dL      (70 - 99)
Cholesterol       214 mg/dL      (125 - 200)
Creatinine        1.0 mg/dL      (0.6 - 1.3)
ALT (SGPT)        62 U/L         (7 - 56)
AST (SGOT)        38 U/L         (10 - 40)
TSH               2.1 mIU/L      (0.4 - 4.0)`;

export function getDemoOcrResult(reason?: string): OcrResult {
  return {
    text: DEMO_OCR_TEXT,
    mode: "demo",
    notes: reason ?? "Real OCR was unavailable, so demo sample text is shown.",
  };
}

async function fileToImageSource(file: File): Promise<Blob | File> {
  if (file.type !== "application/pdf") return file;

  // Render the first PDF page to a canvas so Tesseract can read it.
  const pdfjs = await import("pdfjs-dist");
  const workerSrc = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url")).default;
  pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;

  const data = await file.arrayBuffer();
  const pdf = await pdfjs.getDocument({ data }).promise;
  const page = await pdf.getPage(1);
  const viewport = page.getViewport({ scale: 2 });
  const canvas = document.createElement("canvas");
  canvas.width = viewport.width;
  canvas.height = viewport.height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas is unavailable in this browser.");
  await page.render({ canvas, canvasContext: context, viewport }).promise;

  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
  if (!blob) throw new Error("Could not convert the PDF page to an image.");
  return blob;
}

/**
 * Extract text from an uploaded report.
 * @param onProgress receives 0..1 progress from the recogniser.
 */
export async function extractText(
  file: File,
  onProgress?: (progress: number) => void,
): Promise<OcrResult> {
  if (typeof window === "undefined") {
    return getDemoOcrResult("OCR only runs in the browser.");
  }

  try {
    const source = await fileToImageSource(file);
    const { createWorker } = await import("tesseract.js");
    const worker = await createWorker("eng", 1, {
      logger: (m: { status: string; progress: number }) => {
        if (m.status === "recognizing text") onProgress?.(m.progress);
      },
    });

    try {
      const { data } = await worker.recognize(source);
      const text = (data.text ?? "").trim();
      if (text.length < 12) {
        return getDemoOcrResult("No readable text was found in this file.");
      }
      return { text, mode: "tesseract" };
    } finally {
      await worker.terminate();
    }
  } catch (error) {
    console.error("OCR failed", error);
    const message = error instanceof Error ? error.message : "Unknown OCR error";
    return getDemoOcrResult(`Text recognition could not complete (${message}).`);
  }
}
