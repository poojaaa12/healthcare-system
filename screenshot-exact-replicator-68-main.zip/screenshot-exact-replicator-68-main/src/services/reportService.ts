import { supabase } from "@/integrations/supabase/client";
import type {
  ExplanationResult,
  MedicalParameter,
  OrganMappingResult,
  ReportRecord,
  RiskResult,
  StoredParameter,
} from "@/types";

export const ACCEPTED_TYPES = ["application/pdf", "image/jpeg", "image/jpg", "image/png"];
export const MAX_FILE_BYTES = 20 * 1024 * 1024;
const BUCKET = "medical-reports";

export function validateFile(file: File): string | null {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  const typeOk = ACCEPTED_TYPES.includes(file.type) || ["pdf", "jpg", "jpeg", "png"].includes(ext);
  if (!typeOk) return "Only PDF, JPG, JPEG and PNG files are supported.";
  if (file.size > MAX_FILE_BYTES) return "That file is larger than the 20 MB limit.";
  if (file.size === 0) return "That file appears to be empty.";
  return null;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

/** Uploads the file to private storage and creates the report row. */
export async function createReport(file: File, userId: string): Promise<ReportRecord> {
  const safeName = file.name.replace(/[^\w.\-]+/g, "_");
  const path = `${userId}/${crypto.randomUUID()}-${safeName}`;

  const { error: uploadError } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, { contentType: file.type || "application/octet-stream", upsert: false });
  if (uploadError) throw new Error(`The file could not be stored: ${uploadError.message}`);

  const { data, error } = await supabase
    .from("reports")
    .insert({
      user_id: userId,
      file_name: file.name,
      file_path: path,
      file_type: file.type || null,
      file_size: file.size,
      processing_status: "pending",
    })
    .select()
    .single();

  if (error) {
    await supabase.storage.from(BUCKET).remove([path]);
    throw new Error(`The report could not be saved: ${error.message}`);
  }
  return data as ReportRecord;
}

export async function listReports(): Promise<ReportRecord[]> {
  const { data, error } = await supabase
    .from("reports")
    .select("*")
    .order("upload_date", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as ReportRecord[];
}

export async function getReport(id: string): Promise<ReportRecord | null> {
  const { data, error } = await supabase.from("reports").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return (data as ReportRecord) ?? null;
}

export async function deleteReport(report: ReportRecord): Promise<void> {
  if (report.file_path) await supabase.storage.from(BUCKET).remove([report.file_path]);
  const { error } = await supabase.from("reports").delete().eq("id", report.id);
  if (error) throw new Error(error.message);
}

export async function getSignedUrl(path: string | null): Promise<string | null> {
  if (!path) return null;
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 60 * 30);
  if (error) return null;
  return data.signedUrl;
}

/** Re-downloads the stored file so the pipeline can run after a page reload. */
export async function downloadReportFile(report: ReportRecord): Promise<File | null> {
  if (!report.file_path) return null;
  const { data, error } = await supabase.storage.from(BUCKET).download(report.file_path);
  if (error || !data) return null;
  return new File([data], report.file_name, {
    type: report.file_type || data.type || "application/octet-stream",
  });
}

export async function updateReport(id: string, patch: Record<string, unknown>) {
  const { error } = await supabase.from("reports").update(patch).eq("id", id);
  if (error) throw new Error(error.message);
}

export async function saveParameters(
  reportId: string,
  userId: string,
  parameters: MedicalParameter[],
) {
  await supabase.from("extracted_parameters").delete().eq("report_id", reportId);
  if (parameters.length === 0) return;
  const { error } = await supabase.from("extracted_parameters").insert(
    parameters.map((p) => ({
      report_id: reportId,
      user_id: userId,
      parameter_name: p.parameterName,
      value: p.value,
      raw_value: p.rawValue,
      unit: p.unit,
      reference_range: p.referenceRange,
      status: p.status,
    })),
  );
  if (error) throw new Error(error.message);
}

export async function saveRisk(reportId: string, userId: string, risk: RiskResult) {
  await supabase.from("risk_analysis").delete().eq("report_id", reportId);
  const { error } = await supabase.from("risk_analysis").insert({
    report_id: reportId,
    user_id: userId,
    risk_level: risk.level,
    risk_score: risk.score,
    model_type: risk.modelType,
    analysis_text: risk.analysisText,
  });
  if (error) throw new Error(error.message);
}

export async function saveExplanation(
  reportId: string,
  userId: string,
  explanation: ExplanationResult,
) {
  await supabase.from("ai_explanations").delete().eq("report_id", reportId);
  const { error } = await supabase.from("ai_explanations").insert({
    report_id: reportId,
    user_id: userId,
    explanation: explanation.text,
    model_type: explanation.modelType,
    is_demo: explanation.isDemo,
  });
  if (error) throw new Error(error.message);
}

export async function saveOrganMappings(
  reportId: string,
  userId: string,
  mappings: OrganMappingResult[],
) {
  await supabase.from("organ_mappings").delete().eq("report_id", reportId);
  const { error } = await supabase.from("organ_mappings").insert(
    mappings.map((m) => ({
      report_id: reportId,
      user_id: userId,
      organ_id: m.organId,
      organ_name: m.organName,
      related_parameters: m.relatedParameters,
      status: m.status,
      explanation: m.explanation,
    })),
  );
  if (error) throw new Error(error.message);
}

export async function getParameters(reportId: string): Promise<StoredParameter[]> {
  const { data, error } = await supabase
    .from("extracted_parameters")
    .select("*")
    .eq("report_id", reportId)
    .order("parameter_name");
  if (error) throw new Error(error.message);
  return (data ?? []).map((row) => ({
    id: row.id,
    reportId: row.report_id,
    parameterName: row.parameter_name,
    value: row.value === null ? null : Number(row.value),
    rawValue: row.raw_value ?? String(row.value ?? ""),
    unit: row.unit,
    referenceRange: row.reference_range,
    status: (row.status ?? "unknown") as StoredParameter["status"],
  }));
}

export async function getRisk(reportId: string) {
  const { data } = await supabase
    .from("risk_analysis")
    .select("*")
    .eq("report_id", reportId)
    .maybeSingle();
  return data;
}

export async function getExplanation(reportId: string) {
  const { data } = await supabase
    .from("ai_explanations")
    .select("*")
    .eq("report_id", reportId)
    .maybeSingle();
  return data;
}

export async function getOrganMappings(reportId: string) {
  const { data } = await supabase.from("organ_mappings").select("*").eq("report_id", reportId);
  return data ?? [];
}
