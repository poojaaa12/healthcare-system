import { generateExplanation, buildDemoExplanation } from "@/lib/explanation.functions";
import type { ExplanationResult, MedicalParameter, RiskLevel } from "@/types";

/**
 * Generative AI explanation service.
 *
 * Calls a server function so the API key never reaches the browser. If the AI
 * backend is unavailable, a clearly labelled DEMO AI EXPLANATION is returned.
 */
export async function generatePatientExplanation(
  parameters: MedicalParameter[],
  riskLevel: RiskLevel,
): Promise<ExplanationResult> {
  const payload = {
    parameters: parameters.map((p) => ({
      parameterName: p.parameterName,
      rawValue: p.rawValue,
      unit: p.unit,
      referenceRange: p.referenceRange,
      status: p.status,
    })),
    riskLevel,
  };

  try {
    const result = await generateExplanation({ data: payload });
    return { text: result.text, modelType: result.modelType, isDemo: result.isDemo };
  } catch (error) {
    console.error("Explanation service failed", error);
    return {
      text: buildDemoExplanation(payload),
      modelType: "demo-offline",
      isDemo: true,
    };
  }
}
