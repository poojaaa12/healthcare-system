import { extractText, getDemoOcrResult } from "./ocrService";
import { extractParameters } from "./parameterExtractionService";
import { analyzeText } from "./nlpService";
import { assessRisk } from "./riskService";
import { generatePatientExplanation } from "./explanationService";
import { mapParametersToOrgans } from "./avatarService";
import {
  downloadReportFile,
  saveExplanation,
  saveOrganMappings,
  saveParameters,
  saveRisk,
  updateReport,
} from "./reportService";
import type { ReportRecord } from "@/types";

export const PIPELINE_STAGES = [
  { id: "upload", label: "Upload" },
  { id: "ocr", label: "OCR" },
  { id: "parameters", label: "Parameter Extraction" },
  { id: "nlp", label: "NLP Analysis" },
  { id: "risk", label: "Risk Analysis" },
  { id: "explanation", label: "AI Explanation" },
  { id: "organs", label: "Organ Mapping" },
  { id: "avatar", label: "3D Visualization" },
  { id: "summary", label: "Health Summary" },
] as const;

export type StageId = (typeof PIPELINE_STAGES)[number]["id"];

export interface PipelineEvents {
  onStage: (stage: StageId) => void;
  onProgress?: (fraction: number) => void;
}

/**
 * Runs the full analysis pipeline for a stored report and persists every
 * stage result. Safe to re-run: each save replaces the previous rows.
 */
export async function runPipeline(
  report: ReportRecord,
  userId: string,
  events: PipelineEvents,
): Promise<void> {
  await updateReport(report.id, { processing_status: "processing", processing_error: null });

  events.onStage("upload");
  const file = await downloadReportFile(report);

  events.onStage("ocr");
  const ocr = file
    ? await extractText(file, events.onProgress)
    : getDemoOcrResult("The stored file could not be read back.");
  await updateReport(report.id, { ocr_text: ocr.text, ocr_mode: ocr.mode });

  events.onStage("parameters");
  const parameters = extractParameters(ocr.text);
  await saveParameters(report.id, userId, parameters);

  events.onStage("nlp");
  await analyzeText(ocr.text);

  events.onStage("risk");
  const risk = assessRisk(parameters);
  await saveRisk(report.id, userId, risk);

  events.onStage("explanation");
  const explanation = await generatePatientExplanation(parameters, risk.level);
  await saveExplanation(report.id, userId, explanation);

  events.onStage("organs");
  const organs = mapParametersToOrgans(parameters);
  await saveOrganMappings(report.id, userId, organs);

  events.onStage("avatar");
  events.onStage("summary");

  await updateReport(report.id, {
    processing_status: "completed",
    analyzed_at: new Date().toISOString(),
  });
}
