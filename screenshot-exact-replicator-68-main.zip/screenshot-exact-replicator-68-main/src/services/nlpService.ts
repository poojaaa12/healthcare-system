import { PARAMETER_DEFINITIONS } from "@/data/medicalParameters";
import type { NlpEntity, NlpResult } from "@/types";

/**
 * NLP service abstraction.
 *
 * Today this runs a local, transparent heuristic entity tagger in the browser.
 * The `NlpEngine` interface exists so a real medical NLP backend (spaCy,
 * BioBERT, a Transformers inference endpoint) can be plugged in later without
 * touching any page component — register it with `setNlpEngine`.
 */

export interface NlpEngine {
  name: string;
  analyze(text: string): Promise<NlpResult> | NlpResult;
}

const UNIT_PATTERN = /\b(g\/dL|mg\/dL|mIU\/L|U\/L|10\^\d\/uL|%|mmol\/L)\b/gi;
const NUMBER_PATTERN = /\b\d+(?:\.\d+)?\b/g;
const RANGE_PATTERN = /\d+(?:\.\d+)?\s*(?:-|–|to)\s*\d+(?:\.\d+)?/g;

const MEDICAL_TERMS = [
  "blood",
  "serum",
  "plasma",
  "panel",
  "profile",
  "count",
  "liver function",
  "kidney function",
  "thyroid",
  "lipid",
  "fasting",
];

export const localNlpEngine: NlpEngine = {
  name: "local-heuristic-v1",
  analyze(text: string): NlpResult {
    const entities: NlpEntity[] = [];
    const lower = text.toLowerCase();

    for (const def of PARAMETER_DEFINITIONS) {
      const hit = [def.name.toLowerCase(), ...def.aliases].find((a) => lower.includes(a));
      if (hit) entities.push({ text: def.name, type: "parameter" });
    }
    for (const term of MEDICAL_TERMS) {
      if (lower.includes(term)) entities.push({ text: term, type: "term" });
    }
    for (const match of text.match(RANGE_PATTERN) ?? []) {
      entities.push({ text: match, type: "range" });
    }
    for (const match of text.match(UNIT_PATTERN) ?? []) {
      entities.push({ text: match, type: "unit" });
    }
    for (const match of (text.match(NUMBER_PATTERN) ?? []).slice(0, 40)) {
      entities.push({ text: match, type: "value" });
    }

    const sentences = text
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean);

    return { entities, engine: localNlpEngine.name, sentences };
  },
};

let activeEngine: NlpEngine = localNlpEngine;

/** Swap in a BioBERT / Transformers backend later. */
export function setNlpEngine(engine: NlpEngine) {
  activeEngine = engine;
}

export async function analyzeText(text: string): Promise<NlpResult> {
  return activeEngine.analyze(text);
}
