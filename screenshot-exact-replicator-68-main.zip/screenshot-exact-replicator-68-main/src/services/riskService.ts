import type { MedicalParameter, RiskLevel, RiskResult } from "@/types";

/**
 * PROTOTYPE RISK ANALYSIS.
 *
 * No trained model or validated clinical dataset ships with this project, so
 * no accuracy, precision, recall or F1 figures are claimed anywhere. The
 * indicator below is a transparent rule-based ensemble over how far each
 * parameter sits outside the reference range printed on the report.
 *
 * The `RiskModel` interface is the extension point: a trained Random Forest
 * served over HTTP can be registered with `setRiskModel` and the rest of the
 * application will use it without changes.
 */

export interface RiskModel {
  type: string;
  predict(parameters: MedicalParameter[]): RiskResult;
}

/** Turn a parameter list into numeric features (deviation counts). */
export function buildFeatures(parameters: MedicalParameter[]) {
  const total = parameters.length;
  const high = parameters.filter((p) => p.status === "high").length;
  const low = parameters.filter((p) => p.status === "low").length;
  const abnormal = high + low;
  return {
    total,
    high,
    low,
    abnormal,
    abnormalRatio: total ? abnormal / total : 0,
  };
}

export const prototypeRiskModel: RiskModel = {
  type: "prototype-rule-ensemble",
  predict(parameters: MedicalParameter[]): RiskResult {
    const f = buildFeatures(parameters);
    const contributing = parameters
      .filter((p) => p.status === "high" || p.status === "low")
      .map((p) => p.parameterName);

    const score = Math.min(1, f.abnormalRatio * 0.7 + Math.min(f.abnormal, 4) * 0.075);

    let level: RiskLevel = "LOW";
    if (f.abnormal >= 4 || f.abnormalRatio >= 0.5) level = "HIGH";
    else if (f.abnormal >= 1) level = "MODERATE";

    const analysisText =
      f.total === 0
        ? "No recognisable parameters were found in this report, so no prototype indicator could be produced."
        : `${f.abnormal} of ${f.total} recognised parameters fall outside the reference range shown on the report (${f.high} above, ${f.low} below). This prototype indicator is derived only from that count and spread.`;

    return {
      level,
      score: Number(score.toFixed(3)),
      modelType: prototypeRiskModel.type,
      analysisText,
      contributingParameters: contributing,
    };
  },
};

let activeModel: RiskModel = prototypeRiskModel;

export function setRiskModel(model: RiskModel) {
  activeModel = model;
}

export function assessRisk(parameters: MedicalParameter[]): RiskResult {
  return activeModel.predict(parameters);
}

export const RISK_DISCLAIMER =
  "This is an educational prototype risk indicator and is not a medical diagnosis.";
