import { PARAMETER_DEFINITIONS, findDefinition } from "@/data/medicalParameters";
import type { MedicalParameter, ParameterStatus } from "@/types";

/**
 * Medical parameter extraction.
 *
 * Scans OCR text line by line, matches known parameter aliases, then reads the
 * first numeric value on the line plus any printed reference range such as
 * "(13.0 - 17.0)" or "13.0-17.0". Values are never invented: if a line has no
 * number, the parameter is skipped.
 */

const RANGE_PATTERN = /(\d+(?:\.\d+)?)\s*(?:-|–|to)\s*(\d+(?:\.\d+)?)/;
const NUMBER_PATTERN = /(-?\d+(?:\.\d+)?)/;

function statusFor(
  value: number | null,
  range: { low: number; high: number } | null,
): ParameterStatus {
  if (value === null || !range) return "unknown";
  if (value < range.low) return "low";
  if (value > range.high) return "high";
  return "normal";
}

export function extractParameters(ocrText: string): MedicalParameter[] {
  if (!ocrText?.trim()) return [];

  const lines = ocrText.split(/\r?\n/);
  const found = new Map<string, MedicalParameter>();

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;
    const lower = line.toLowerCase();

    for (const def of PARAMETER_DEFINITIONS) {
      if (found.has(def.name)) continue;

      const alias = [def.name.toLowerCase(), ...def.aliases].find((a) => {
        const index = lower.indexOf(a);
        if (index === -1) return false;
        // Require a word boundary so "hb" does not match inside "hba1c".
        const before = index === 0 ? " " : lower[index - 1]!;
        const after = lower[index + a.length] ?? " ";
        return !/[a-z0-9]/.test(before) && !/[a-z0-9]/.test(after);
      });
      if (!alias) continue;

      const afterLabel = line.slice(lower.indexOf(alias) + alias.length);

      // A printed reference range, if the lab included one.
      const rangeMatch = afterLabel.match(RANGE_PATTERN);
      let printedRange: { low: number; high: number } | null = null;
      let referenceRange: string | null = null;
      if (rangeMatch) {
        printedRange = { low: Number(rangeMatch[1]), high: Number(rangeMatch[2]) };
        referenceRange = `${rangeMatch[1]} - ${rangeMatch[2]}`;
      }

      // The measured value: first number before the reference range.
      const valueSegment = rangeMatch
        ? afterLabel.slice(0, afterLabel.indexOf(rangeMatch[0]))
        : afterLabel;
      const valueMatch = valueSegment.match(NUMBER_PATTERN);
      if (!valueMatch) continue;
      const value = Number(valueMatch[1]);
      if (Number.isNaN(value)) continue;

      const effectiveRange = printedRange ?? def.typicalRange;
      found.set(def.name, {
        parameterName: def.name,
        value,
        rawValue: valueMatch[1]!,
        unit: def.unit,
        referenceRange: referenceRange ?? `${def.typicalRange.low} - ${def.typicalRange.high} (typical adult range)`,
        status: statusFor(value, effectiveRange),
      });
    }
  }

  return [...found.values()];
}

/** Plain-language, non-diagnostic note about a single parameter. */
export function describeParameter(parameter: MedicalParameter): string {
  const def = findDefinition(parameter.parameterName);
  const about = def?.about ?? "This value was read from your report.";
  switch (parameter.status) {
    case "high":
      return `${about} This result is above the reference range shown on the report. A healthcare professional can explain what that means for you.`;
    case "low":
      return `${about} This result is below the reference range shown on the report. A healthcare professional can explain what that means for you.`;
    case "normal":
      return `${about} This result falls inside the reference range shown on the report.`;
    default:
      return `${about} No reference range was available, so this result was not compared.`;
  }
}
