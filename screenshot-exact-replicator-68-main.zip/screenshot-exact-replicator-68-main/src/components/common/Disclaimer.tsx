import { ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";
import { MEDICAL_DISCLAIMER } from "@/types";

export function Disclaimer({ className, text }: { className?: string; text?: string }) {
  return (
    <div
      className={cn(
        "flex items-start gap-3 rounded-xl border border-border bg-muted/60 p-4 text-sm text-muted-foreground",
        className,
      )}
    >
      <ShieldAlert className="mt-0.5 size-4 shrink-0 text-primary" />
      <p>{text ?? MEDICAL_DISCLAIMER}</p>
    </div>
  );
}
