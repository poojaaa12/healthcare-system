/**
 * Minimal markdown renderer for AI explanation output.
 * Supports ### headings, **bold** lines, > callouts, _italics_ and paragraphs.
 */
export function RichText({ content }: { content: string }) {
  const blocks = content.split(/\n{2,}/);

  return (
    <div className="space-y-4">
      {blocks.map((block, i) => {
        const trimmed = block.trim();
        if (!trimmed) return null;

        if (trimmed.startsWith("###")) {
          const [heading, ...rest] = trimmed.split("\n");
          return (
            <div key={i} className="space-y-2">
              <h3 className="text-base font-semibold text-foreground">
                {heading!.replace(/^#+\s*/, "")}
              </h3>
              {rest.length > 0 && <Lines text={rest.join("\n")} />}
            </div>
          );
        }

        if (trimmed.startsWith(">")) {
          return (
            <p
              key={i}
              className="rounded-xl border border-warning/40 bg-warning/12 p-3 text-sm font-medium text-warning-foreground"
            >
              {trimmed.replace(/^>\s*/gm, "").replace(/\*\*/g, "")}
            </p>
          );
        }

        return <Lines key={i} text={trimmed} />;
      })}
    </div>
  );
}

function Lines({ text }: { text: string }) {
  return (
    <div className="space-y-1.5">
      {text.split("\n").map((line, i) => {
        const l = line.trim();
        if (!l) return null;
        if (/^\*\*.+\*\*$/.test(l)) {
          return (
            <p key={i} className="text-sm font-semibold text-primary">
              {l.replace(/\*\*/g, "")}
            </p>
          );
        }
        if (/^_.+_$/.test(l)) {
          return (
            <p key={i} className="text-xs italic text-muted-foreground">
              {l.replace(/_/g, "")}
            </p>
          );
        }
        return (
          <p key={i} className="text-sm leading-relaxed text-muted-foreground">
            {l.replace(/\*\*/g, "").replace(/^[-*]\s*/, "• ")}
          </p>
        );
      })}
    </div>
  );
}
