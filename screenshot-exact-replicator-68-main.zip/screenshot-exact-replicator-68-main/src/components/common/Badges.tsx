import { cn } from "@/lib/utils";
import type { OrganStatus, ParameterStatus, RiskLevel } from "@/types";

const base =
  "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold tracking-wide";

export function StatusBadge({ status }: { status: ParameterStatus }) {
  const map: Record<ParameterStatus, string> = {
    normal: "bg-success/12 text-success",
    high: "bg-destructive/12 text-destructive",
    low: "bg-warning/18 text-warning-foreground",
    unknown: "bg-muted text-muted-foreground",
  };
  const label: Record<ParameterStatus, string> = {
    normal: "In range",
    high: "Above range",
    low: "Below range",
    unknown: "Not compared",
  };
  return <span className={cn(base, map[status])}>{label[status]}</span>;
}

export function RiskBadge({ level, className }: { level: RiskLevel | string; className?: string }) {
  const map: Record<string, string> = {
    LOW: "bg-success/12 text-success",
    MODERATE: "bg-warning/18 text-warning-foreground",
    HIGH: "bg-destructive/12 text-destructive",
  };
  return (
    <span className={cn(base, map[level] ?? "bg-muted text-muted-foreground", className)}>
      {level} RISK INDICATOR
    </span>
  );
}

export function OrganStatusBadge({ status }: { status: OrganStatus }) {
  const map: Record<OrganStatus, string> = {
    normal: "bg-success/12 text-success",
    attention: "bg-warning/18 text-warning-foreground",
    unmapped: "bg-muted text-muted-foreground",
  };
  const label: Record<OrganStatus, string> = {
    normal: "Mapped · in range",
    attention: "Needs attention",
    unmapped: "Not mapped",
  };
  return <span className={cn(base, map[status])}>{label[status]}</span>;
}

export function DemoBadge({ label = "DEMO / PROTOTYPE DATA" }: { label?: string }) {
  return (
    <span className={cn(base, "border border-warning/40 bg-warning/15 text-warning-foreground")}>
      {label}
    </span>
  );
}
