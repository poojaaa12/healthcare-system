import { lazy, Suspense, useEffect, useState } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { Maximize2, RotateCcw, MousePointerClick, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { OrganStatusBadge } from "@/components/common/Badges";
import { ORGANS } from "@/data/organs";
import { avatarModelExists } from "@/services/avatarService";
import type { OrganMappingResult } from "@/types";

// Three.js must never be imported during SSR, so the scene loads after hydration.
const AvatarScene = lazy(() => import("./AvatarScene"));

function Placeholder({ message }: { message: string }) {
  return (
    <div className="grid h-full w-full place-items-center gap-2 text-sm text-muted-foreground">
      <div className="flex items-center gap-2">
        <Loader2 className="size-4 animate-spin" />
        {message}
      </div>
    </div>
  );
}

export function MediAvatarViewer({ mappings }: { mappings: OrganMappingResult[] }) {
  const [selected, setSelected] = useState<string | null>(null);
  const [hasModel, setHasModel] = useState(false);

  useEffect(() => {
    let active = true;
    avatarModelExists().then((exists) => {
      if (active) setHasModel(exists);
    });
    return () => {
      active = false;
    };
  }, []);

  const organ = ORGANS.find((o) => o.id === selected);
  const mapping = mappings.find((m) => m.organId === selected);

  return (
    <div className="grid gap-5 lg:grid-cols-[1.6fr_1fr]">
      <div className="relative h-[460px] overflow-hidden rounded-2xl border border-border bg-[oklch(0.2_0.04_248)] shadow-soft sm:h-[560px]">
        <ClientOnly fallback={<Placeholder message="Preparing 3D viewer…" />}>
          <Suspense fallback={<Placeholder message="Loading the MediAvatar…" />}>
            <AvatarScene
              mappings={mappings}
              selectedOrganId={selected}
              onSelect={setSelected}
              useCustomModel={hasModel}
            />
          </Suspense>
        </ClientOnly>

        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3">
          <span className="pointer-events-auto rounded-full bg-background/85 px-3 py-1 text-[11px] font-medium text-muted-foreground backdrop-blur">
            {hasModel ? "Custom GLB model loaded" : "Demo body representation (no GLB model added)"}
          </span>
          <Button
            size="sm"
            variant="secondary"
            className="pointer-events-auto"
            onClick={() => window.dispatchEvent(new Event("mediavatar:reset"))}
          >
            <RotateCcw className="mr-1.5 size-3.5" /> Reset view
          </Button>
        </div>

        <p className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 p-3 text-[11px] text-muted-foreground">
          <MousePointerClick className="size-3.5" /> Drag to rotate · scroll to zoom · right-drag to
          pan · click an organ
        </p>
      </div>

      <div className="panel flex flex-col gap-3 p-5">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-base font-semibold">Organ information</h3>
          <Maximize2 className="size-4 text-muted-foreground" />
        </div>

        {!organ ? (
          <p className="text-sm text-muted-foreground">
            Select an organ in the avatar to see which parameters from this report are associated
            with it.
          </p>
        ) : (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <h4 className="font-display text-lg font-semibold">{organ.name}</h4>
              <OrganStatusBadge status={mapping?.status ?? "unmapped"} />
            </div>
            <p className="text-sm text-muted-foreground">{organ.description}</p>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Related parameters
              </p>
              <p className="text-sm">
                {mapping?.relatedParameters.length
                  ? mapping.relatedParameters.join(", ")
                  : "None found in this report"}
              </p>
            </div>
            <p className="rounded-xl bg-muted/70 p-3 text-sm text-muted-foreground">
              {mapping?.explanation ??
                `No parameters in this report are mapped to the ${organ.name.toLowerCase()}.`}
            </p>
          </div>
        )}

        <div className="mt-auto space-y-2 border-t border-border pt-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Legend
          </p>
          <ul className="space-y-1.5 text-xs text-muted-foreground">
            <li>Teal — mapped parameters are inside the report's reference range.</li>
            <li>Amber — mapped parameters fall outside the reference range.</li>
            <li>Grey — no parameters in this report map to that organ.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
