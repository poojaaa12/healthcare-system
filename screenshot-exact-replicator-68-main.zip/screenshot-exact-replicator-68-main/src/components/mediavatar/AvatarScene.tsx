import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Environment, Html, ContactShadows, useGLTF } from "@react-three/drei";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { ORGANS } from "@/data/organs";
import { AVATAR_MODEL_URL } from "@/services/avatarService";
import type { OrganMappingResult, OrganStatus } from "@/types";

/** Colours are scene materials, not UI styling, so literal values are used. */
const STATUS_COLOR: Record<OrganStatus, string> = {
  attention: "#e0823f",
  normal: "#2fb39a",
  unmapped: "#7d93a8",
};

interface SceneProps {
  mappings: OrganMappingResult[];
  selectedOrganId: string | null;
  onSelect: (organId: string) => void;
  useCustomModel: boolean;
}

function CustomModel() {
  const gltf = useGLTF(AVATAR_MODEL_URL);
  return <primitive object={gltf.scene} position={[0, 0, 0]} />;
}

/** Fallback demo body built from primitives, used when no GLB model is added. */
function DemoBody() {
  const material = { color: "#9fc6d8", transparent: true, opacity: 0.22 } as const;
  return (
    <group>
      <mesh position={[0, 1.62, 0]}>
        <sphereGeometry args={[0.14, 32, 32]} />
        <meshStandardMaterial {...material} />
      </mesh>
      <mesh position={[0, 1.42, 0]}>
        <cylinderGeometry args={[0.05, 0.06, 0.12, 24]} />
        <meshStandardMaterial {...material} />
      </mesh>
      <mesh position={[0, 1.02, 0]}>
        <capsuleGeometry args={[0.21, 0.42, 8, 24]} />
        <meshStandardMaterial {...material} />
      </mesh>
      <mesh position={[0, 0.66, 0]}>
        <capsuleGeometry args={[0.17, 0.16, 8, 24]} />
        <meshStandardMaterial {...material} />
      </mesh>
      {[-0.28, 0.28].map((x) => (
        <mesh key={x} position={[x, 1.02, 0]} rotation={[0, 0, x > 0 ? -0.08 : 0.08]}>
          <capsuleGeometry args={[0.055, 0.5, 8, 16]} />
          <meshStandardMaterial {...material} />
        </mesh>
      ))}
      {[-0.1, 0.1].map((x) => (
        <mesh key={x} position={[x, 0.26, 0]}>
          <capsuleGeometry args={[0.07, 0.52, 8, 16]} />
          <meshStandardMaterial {...material} />
        </mesh>
      ))}
    </group>
  );
}

function OrganMesh({
  organId,
  mapping,
  selected,
  onSelect,
}: {
  organId: string;
  mapping: OrganMappingResult | undefined;
  selected: boolean;
  onSelect: (id: string) => void;
}) {
  const organ = ORGANS.find((o) => o.id === organId)!;
  const [hovered, setHovered] = useState(false);
  const status = mapping?.status ?? "unmapped";
  const color = STATUS_COLOR[status];

  return (
    <group position={organ.position}>
      <mesh
        scale={organ.scale}
        onClick={(e) => {
          e.stopPropagation();
          onSelect(organ.id);
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          setHovered(true);
        }}
        onPointerOut={() => setHovered(false)}
      >
        <sphereGeometry args={[1, 32, 32]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={selected ? 1.1 : hovered ? 0.7 : status === "attention" ? 0.45 : 0.2}
          roughness={0.35}
          metalness={0.1}
        />
      </mesh>
      {(hovered || selected) && (
        <Html distanceFactor={1.4} position={[0, organ.scale[1] + 0.06, 0]} center>
          <span className="pointer-events-none whitespace-nowrap rounded-md bg-card/95 px-2 py-1 text-[10px] font-semibold text-foreground shadow-soft">
            {organ.name}
          </span>
        </Html>
      )}
    </group>
  );
}

export default function AvatarScene({
  mappings,
  selectedOrganId,
  onSelect,
  useCustomModel,
}: SceneProps) {
  const controlsRef = useRef<OrbitControlsImpl | null>(null);
  const byId = useMemo(() => new Map(mappings.map((m) => [m.organId, m])), [mappings]);

  useEffect(() => {
    const handler = () => controlsRef.current?.reset();
    window.addEventListener("mediavatar:reset", handler);
    return () => window.removeEventListener("mediavatar:reset", handler);
  }, []);

  return (
    <Canvas camera={{ position: [0, 1.15, 2.1], fov: 42 }} dpr={[1, 2]}>
      <color attach="background" args={["#0d1b2a"]} />
      <ambientLight intensity={0.6} />
      <directionalLight position={[2, 4, 3]} intensity={1.2} />
      <directionalLight position={[-3, 2, -2]} intensity={0.5} color="#5ad2e6" />
      <Suspense fallback={null}>
        {useCustomModel ? <CustomModel /> : <DemoBody />}
        <Environment preset="city" />
      </Suspense>
      {ORGANS.map((organ) => (
        <OrganMesh
          key={organ.id}
          organId={organ.id}
          mapping={byId.get(organ.id)}
          selected={selectedOrganId === organ.id}
          onSelect={onSelect}
        />
      ))}
      <ContactShadows position={[0, 0, 0]} opacity={0.35} blur={2.5} scale={4} far={2} />
      <OrbitControls
        ref={controlsRef}
        enablePan
        enableZoom
        minDistance={0.8}
        maxDistance={5}
        target={[0, 1.05, 0]}
      />
    </Canvas>
  );
}
