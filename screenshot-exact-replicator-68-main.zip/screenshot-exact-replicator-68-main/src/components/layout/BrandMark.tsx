import { Link } from "@tanstack/react-router";
import { Activity } from "lucide-react";
import { cn } from "@/lib/utils";

export function BrandMark({ className, to = "/" }: { className?: string; to?: string }) {
  return (
    <Link to={to} className={cn("group flex items-center gap-2.5", className)}>
      <span className="grid size-9 place-items-center rounded-xl bg-brand-gradient shadow-glow">
        <Activity className="size-5 text-primary-foreground" />
      </span>
      <span className="font-display text-lg font-semibold tracking-tight">
        MediAvatar <span className="text-brand-gradient">3D</span>
      </span>
    </Link>
  );
}
