/**
 * Dictionary of medical parameters the prototype can recognise.
 *
 * `aliases` drive OCR text matching. `typicalRange` is used ONLY when the
 * report itself does not print a reference range — it is a widely published
 * adult reference interval and is always displayed as "typical adult range"
 * so it is never confused with the laboratory's own range.
 */

export interface ParameterDefinition {
  name: string;
  aliases: string[];
  unit: string;
  typicalRange: { low: number; high: number };
  /** Short, non-diagnostic description of what the parameter measures. */
  about: string;
  organs: string[];
}

export const PARAMETER_DEFINITIONS: ParameterDefinition[] = [
  {
    name: "Hemoglobin",
    aliases: ["hemoglobin", "haemoglobin", "hgb", "hb"],
    unit: "g/dL",
    typicalRange: { low: 12, high: 17 },
    about: "A protein in red blood cells that carries oxygen around the body.",
    organs: ["heart", "lungs"],
  },
  {
    name: "WBC",
    aliases: ["wbc", "white blood cell", "white blood cells", "leukocyte", "total leucocyte count", "tlc"],
    unit: "10^3/uL",
    typicalRange: { low: 4, high: 11 },
    about: "White blood cells are part of the body's immune defence.",
    organs: ["lungs"],
  },
  {
    name: "RBC",
    aliases: ["rbc", "red blood cell", "red blood cells", "erythrocyte"],
    unit: "10^6/uL",
    typicalRange: { low: 4.2, high: 5.9 },
    about: "Red blood cells transport oxygen from the lungs to the tissues.",
    organs: ["heart", "lungs"],
  },
  {
    name: "Platelets",
    aliases: ["platelet", "platelets", "plt", "platelet count"],
    unit: "10^3/uL",
    typicalRange: { low: 150, high: 450 },
    about: "Cell fragments that help blood to clot.",
    organs: ["liver"],
  },
  {
    name: "Glucose",
    aliases: ["glucose", "blood sugar", "fasting glucose", "fbs", "fasting blood sugar"],
    unit: "mg/dL",
    typicalRange: { low: 70, high: 99 },
    about: "The amount of sugar circulating in the blood.",
    organs: ["pancreas", "liver"],
  },
  {
    name: "Cholesterol",
    aliases: ["cholesterol", "total cholesterol", "serum cholesterol"],
    unit: "mg/dL",
    typicalRange: { low: 125, high: 200 },
    about: "A fatty substance in the blood used to build cells and hormones.",
    organs: ["heart", "liver"],
  },
  {
    name: "Creatinine",
    aliases: ["creatinine", "serum creatinine", "s. creatinine"],
    unit: "mg/dL",
    typicalRange: { low: 0.6, high: 1.3 },
    about: "A waste product filtered out of the blood by the kidneys.",
    organs: ["kidneys"],
  },
  {
    name: "ALT",
    aliases: ["alt", "sgpt", "alanine aminotransferase", "alt (sgpt)"],
    unit: "U/L",
    typicalRange: { low: 7, high: 56 },
    about: "A liver enzyme commonly measured in liver function panels.",
    organs: ["liver"],
  },
  {
    name: "AST",
    aliases: ["ast", "sgot", "aspartate aminotransferase", "ast (sgot)"],
    unit: "U/L",
    typicalRange: { low: 10, high: 40 },
    about: "An enzyme found in the liver and other tissues.",
    organs: ["liver"],
  },
  {
    name: "TSH",
    aliases: ["tsh", "thyroid stimulating hormone", "thyroid-stimulating hormone"],
    unit: "mIU/L",
    typicalRange: { low: 0.4, high: 4.0 },
    about: "A hormone that signals the thyroid gland to produce thyroid hormones.",
    organs: ["thyroid"],
  },
  {
    name: "Urea",
    aliases: ["urea", "blood urea", "bun", "blood urea nitrogen"],
    unit: "mg/dL",
    typicalRange: { low: 7, high: 20 },
    about: "A waste product removed from the blood by the kidneys.",
    organs: ["kidneys"],
  },
  {
    name: "Bilirubin",
    aliases: ["bilirubin", "total bilirubin", "serum bilirubin"],
    unit: "mg/dL",
    typicalRange: { low: 0.1, high: 1.2 },
    about: "A yellow substance processed by the liver.",
    organs: ["liver"],
  },
  {
    name: "Amylase",
    aliases: ["amylase", "serum amylase"],
    unit: "U/L",
    typicalRange: { low: 30, high: 110 },
    about: "A digestive enzyme produced mainly by the pancreas.",
    organs: ["pancreas", "stomach"],
  },
  {
    name: "HbA1c",
    aliases: ["hba1c", "glycated hemoglobin", "a1c", "glycosylated hemoglobin"],
    unit: "%",
    typicalRange: { low: 4, high: 5.7 },
    about: "Reflects average blood sugar over the previous few months.",
    organs: ["pancreas"],
  },
];

export function findDefinition(name: string): ParameterDefinition | undefined {
  const needle = name.trim().toLowerCase();
  return PARAMETER_DEFINITIONS.find(
    (d) => d.name.toLowerCase() === needle || d.aliases.includes(needle),
  );
}
