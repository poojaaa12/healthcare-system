import type { OrganDefinition } from "@/types";

/**
 * Reusable organ data structure driving both the 3D avatar and the
 * organ-mapping service. Positions are relative to the avatar body origin.
 */
export const ORGANS: OrganDefinition[] = [
  {
    id: "brain",
    name: "Brain",
    description: "Controls thought, movement and the body's regulatory systems.",
    relatedParameters: [],
    position: [0, 1.62, 0],
    scale: [0.2, 0.2, 0.2],
  },
  {
    id: "thyroid",
    name: "Thyroid",
    description: "A gland in the neck that helps regulate metabolism.",
    relatedParameters: ["TSH"],
    position: [0, 1.36, 0.06],
    scale: [0.09, 0.05, 0.06],
  },
  {
    id: "lungs",
    name: "Lungs",
    description: "Move oxygen into the blood and carbon dioxide out of it.",
    relatedParameters: ["WBC", "RBC", "Hemoglobin"],
    position: [0, 1.08, 0],
    scale: [0.28, 0.22, 0.14],
  },
  {
    id: "heart",
    name: "Heart",
    description: "Pumps blood through the circulatory system.",
    relatedParameters: ["Cholesterol", "Hemoglobin", "RBC"],
    position: [-0.06, 1.08, 0.06],
    scale: [0.1, 0.11, 0.09],
  },
  {
    id: "liver",
    name: "Liver",
    description: "Processes nutrients, filters blood and produces proteins.",
    relatedParameters: ["ALT", "AST", "Bilirubin", "Platelets", "Cholesterol"],
    position: [0.09, 0.9, 0.03],
    scale: [0.18, 0.1, 0.12],
  },
  {
    id: "stomach",
    name: "Stomach",
    description: "Breaks down food at the start of digestion.",
    relatedParameters: ["Amylase"],
    position: [-0.08, 0.86, 0.03],
    scale: [0.1, 0.09, 0.08],
  },
  {
    id: "pancreas",
    name: "Pancreas",
    description: "Produces digestive enzymes and insulin.",
    relatedParameters: ["Glucose", "HbA1c", "Amylase"],
    position: [0, 0.79, 0],
    scale: [0.15, 0.04, 0.06],
  },
  {
    id: "kidneys",
    name: "Kidneys",
    description: "Filter waste products from the blood into urine.",
    relatedParameters: ["Creatinine", "Urea"],
    position: [0, 0.72, -0.06],
    scale: [0.22, 0.08, 0.07],
  },
];

export function getOrgan(id: string): OrganDefinition | undefined {
  return ORGANS.find((o) => o.id === id);
}
