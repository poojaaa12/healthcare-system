import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const parameterSchema = z.object({
  parameterName: z.string(),
  rawValue: z.string(),
  unit: z.string().nullable(),
  referenceRange: z.string().nullable(),
  status: z.string(),
});

const inputSchema = z.object({
  parameters: z.array(parameterSchema).max(40),
  riskLevel: z.string(),
});

export type ExplanationInput = z.infer<typeof inputSchema>;

const SYSTEM_PROMPT = `You are a careful health-literacy assistant inside an academic prototype called MediAvatar 3D.
You explain laboratory parameters in plain, calm language for a non-medical reader.

Hard rules — never break them:
- Never diagnose a condition or suggest one is likely.
- Never prescribe medication, treatment, supplements or dosages.
- Never invent laboratory values, patient details or medical history. Use only the values given to you.
- Never claim certainty, and never present yourself as a doctor.
- Always encourage the reader to discuss results with a qualified healthcare professional.

For EACH parameter provided, output a markdown section using exactly these headings:
### <Parameter name>
**What is this parameter?**
**Your result**
**Reference range**
**What does it mean?**
**Why is it important?**
**When should I consult a healthcare professional?**

Keep each answer to one or two short sentences. End the whole response with a single line:
_This explanation is educational and is not a medical diagnosis._`;

/** Builds a clearly-labelled offline explanation when no AI backend answers. */
export function buildDemoExplanation(input: ExplanationInput): string {
  const sections = input.parameters
    .map(
      (p) => `### ${p.parameterName}
**What is this parameter?**
A value reported in your laboratory report.

**Your result**
${p.rawValue}${p.unit ? ` ${p.unit}` : ""} (${p.status})

**Reference range**
${p.referenceRange ?? "Not printed on the report"}

**What does it mean?**
Your result is ${p.status === "normal" ? "inside" : p.status === "unknown" ? "not comparable to" : "outside"} the reference range shown on the report.

**Why is it important?**
Laboratories compare each value against a reference range to show how typical it is.

**Why is it important to discuss it?**
Only a qualified professional can interpret this alongside your full health picture.

**When should I consult a healthcare professional?**
Discuss this report with a healthcare professional, especially if you feel unwell.`,
    )
    .join("\n\n");

  return `> **DEMO AI EXPLANATION** — generated offline by the prototype, not by a language model.\n\n${sections}\n\n_This explanation is educational and is not a medical diagnosis._`;
}

export const generateExplanation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => inputSchema.parse(data))
  .handler(async ({ data }) => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey || data.parameters.length === 0) {
      return { text: buildDemoExplanation(data), modelType: "demo-offline", isDemo: true };
    }

    const userPrompt = `Preliminary prototype risk indicator: ${data.riskLevel}.
Parameters read from the report:
${data.parameters
  .map(
    (p) =>
      `- ${p.parameterName}: ${p.rawValue}${p.unit ? ` ${p.unit}` : ""} | reference range: ${p.referenceRange ?? "not printed"} | status: ${p.status}`,
  )
  .join("\n")}`;

    try {
      const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3.8-flash",
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            { role: "user", content: userPrompt },
          ],
        }),
      });

      if (response.status === 429) {
        return {
          text: buildDemoExplanation(data),
          modelType: "demo-offline",
          isDemo: true,
          notice: "The AI service is busy right now, so a demo explanation is shown.",
        };
      }
      if (!response.ok) {
        console.error("AI gateway error", response.status, await response.text());
        return { text: buildDemoExplanation(data), modelType: "demo-offline", isDemo: true };
      }

      const payload = (await response.json()) as {
        choices?: { message?: { content?: string } }[];
      };
      const text = payload.choices?.[0]?.message?.content?.trim();
      if (!text) {
        return { text: buildDemoExplanation(data), modelType: "demo-offline", isDemo: true };
      }
      return { text, modelType: "google/gemini-3.8-flash", isDemo: false };
    } catch (error) {
      console.error("Explanation generation failed", error);
      return { text: buildDemoExplanation(data), modelType: "demo-offline", isDemo: true };
    }
  });
