/** Shared domain types for MediAvatar 3D. */

export type ParameterStatus = "low" | "normal" | "high" | "unknown";
export type RiskLevel = "LOW" | "MODERATE" | "HIGH";
export type OrganStatus = "normal" | "attention" | "unmapped";
export type ProcessingStatus = "pending" | "processing" | "completed" | "failed";

/** A single medical parameter read from a report. */
export interface MedicalParameter {
  parameterName: string;
  value: number | null;
  rawValue: string;
  unit: string | null;
  referenceRange: string | null;
  status: ParameterStatus;
}

export interface StoredParameter extends MedicalParameter {
  id: string;
  reportId: string;
}

/** Result of the OCR stage. */
export interface OcrResult {
  text: string;
  /** "tesseract" for real OCR, "demo" for the clearly-labelled fallback. */
  mode: "tesseract" | "demo";
  notes?: string;
}

export interface NlpEntity {
  text: string;
  type: "parameter" | "value" | "unit" | "range" | "term";
}

export interface NlpResult {
  entities: NlpEntity[];
  /** Which backend produced this: local heuristics today, BioBERT later. */
  engine: string;
  sentences: string[];
}

export interface RiskResult {
  level: RiskLevel;
  score: number;
  modelType: string;
  analysisText: string;
  contributingParameters: string[];
}

export interface OrganDefinition {
  id: string;
  name: string;
  description: string;
  /** Canonical parameter names commonly associated with this organ. */
  relatedParameters: string[];
  /** Approximate position in the 3D avatar, in metres. */
  position: [number, number, number];
  scale: [number, number, number];
}

export interface OrganMappingResult {
  organId: string;
  organName: string;
  relatedParameters: string[];
  status: OrganStatus;
  explanation: string;
}

export interface ExplanationResult {
  text: string;
  modelType: string;
  isDemo: boolean;
}

export interface ReportRecord {
  id: string;
  user_id: string;
  file_name: string;
  file_path: string | null;
  file_type: string | null;
  file_size: number | null;
  upload_date: string;
  processing_status: string;
  processing_error: string | null;
  ocr_text: string | null;
  ocr_mode: string | null;
  analyzed_at: string | null;
  created_at: string;
  updated_at: string;
}

export const MEDICAL_DISCLAIMER =
  "Medical Disclaimer: MediAvatar 3D is an academic prototype intended for educational and informational purposes only. It does not provide medical diagnosis, treatment, or professional medical advice.";
